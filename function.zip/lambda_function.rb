require 'json'
require 'notion_api'

def lambda_handler(event:, context:)
  client = NotionAPI::Client.new("secret_hPZNXnkkD97Gh8EhKHrFKyz98CtTaFphQuhRa7M8buY")

  puts @client.get_page("https://www.notion.so/a49914ab5b20401a924e3517572ed6d5?v=e180f9a8c602477f8bb4108520d3109a")
end
